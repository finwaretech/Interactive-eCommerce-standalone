<?php
$id=isset($_GET['id'])?$_GET['id']:"592";
$width=749;
$height=499;
if($id=="611")
{


$product_name="French Essentials";
$image_gif="592.gif";
$image_1="592_1.jpg";
$image_2="592_2.jpg";
$image_3="592_3.jpg";
$image_4="592_4.jpg";
} 


if($id=="612")
{


$product_name="Lets Learn Our Numbers";
$image_gif="595.gif";
$image_1="595_1.jpg";
$image_2="595_2.jpg";
$image_3="595_3.jpg";
$image_4="595_4.jpg";
}


if($id=="613")
{


$product_name="Lets Learn Our Small Letters";
$image_gif="596.gif";
$image_1="596_1.jpg";
$image_2="596_2.jpg";
$image_3="596_3.jpg";
$image_4="596_4.jpg";
}


if($id=="614")
{


$product_name="Lets Learn Our Timestable";
$image_gif="597.gif";
$image_1="597_1.jpg";
$image_2="597_2.jpg";
$image_3="597_3.jpg";
$image_4="597_4.jpg";
}

if($id=="615")
{
$product_name="Its Your Turn To Add Up";
$image_gif="604.gif";
$image_1="604_1.jpg";
$image_2="604_2.jpg";
$image_3="604_3.jpg";
$image_4="604_4.jpg";
}

if($id=="592")
{


$product_name="French Essentials";
$image_gif="592.gif";
$image_1="592_1.jpg";
$image_2="592_2.jpg";
$image_3="592_3.jpg";
$image_4="592_4.jpg";
} 


if($id=="595")
{


$product_name="Lets Learn Our Numbers";
$image_gif="595.gif";
$image_1="595_1.jpg";
$image_2="595_2.jpg";
$image_3="595_3.jpg";
$image_4="595_4.jpg";
}


if($id=="596")
{


$product_name="Lets Learn Our Small Letters";
$image_gif="596.gif";
$image_1="596_1.jpg";
$image_2="596_2.jpg";
$image_3="596_3.jpg";
$image_4="596_4.jpg";
}


if($id=="597")
{


$product_name="Lets Learn Our Timestable";
$image_gif="597.gif";
$image_1="597_1.jpg";
$image_2="597_2.jpg";
$image_3="597_3.jpg";
$image_4="597_4.jpg";
}

if($id=="604")
{
$product_name="Its Your Turn To Add Up";
$image_gif="604.gif";
$image_1="604_1.jpg";
$image_2="604_2.jpg";
$image_3="604_3.jpg";
$image_4="604_4.jpg";
}

if($id=="607")
{


$product_name="Lets Learn How To Subtract";
$image_gif="607.gif";
$image_1="607_1.jpg";
$image_2="607_2.jpg";
$image_3="607_3.jpg";
$image_4="607_4.jpg";
}

if($id=="608")
{


$product_name="Lets Learn Our Timestable 3";
$image_gif="608.gif";
$image_1="608_1.jpg";
$image_2="608_2.jpg";
$image_3="608_3.jpg";
$image_4="608_4.jpg";
}

if($id=="609")
{


$product_name="Lets Learn Our Cursive";
$image_gif="609.gif";
$image_1="609_1.jpg";
$image_2="609_2.jpg";
$image_3="609_3.jpg";
$image_4="609_4.jpg";
}

if($id=="610")
{


$product_name="Spanish Essentials";
$image_gif="610.gif";
$image_1="610_1.jpg";
$image_2="610_2.jpg";
$image_3="610_3.jpg";
$image_4="610_4.jpg";
}
?>





<!DOCTYPE html>

<html dir="ltr" lang="en">



<!-- Mirrored from www.educationallearningmats.co.uk/index.php?route=product/product&product_id=62 by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 28 Mar 2016 11:56:14 GMT -->

<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->

<head>

<meta charset="UTF-8" />

<title>French Numbers -  | Educational Learning Mats</title>

<base  />

<meta name="description" content="French Essentials: Numbers – Mat 1



· Help with learning numbers in French from 1 to 100, 1000s, 1,000,000s for Key Stage 2 &amp; 3 (age 7 to 13)



· The simple rules of French numbers and their variations are clearly explained on the front with exampl" />

<meta name="keywords" content="educational learning mats, elmats, learning mat , learning mats , early learning Math, early keystage learning, keystage learning , Early Learning , Direct Teaching , Home school, Discover elmats , home teaching ideas , number mats , learning to write , loving to learn ,  early learning mats , primary school tools , primary school resources , primary classroom resources ,  show me mats,  abc write on mats , learning french mats , lets learn numbers , learning basic french , lets learn letters , lets learn , times table learning mats , writing letters mats , learning to write letters , learn top write numbers , learn times table mats , safe for kids mats , left hand alphabet , left hand numbers" />

<link href="image/data/ELM16x16.jpg" rel="icon" />



<!-- FBOG /-->

<meta property="og:title" content="French Numbers -  | Educational Learning Mats"/>

<meta property="og:type" content="website"/>

<meta property="og:url" content="index2963.html?route=product/product&amp;product_id=62"/>

<meta property="og:site_name" content="Educational Learning Mats"/>

<meta property="fb:admins" content="627245220"/>

<meta property="og:description" content="French Essentials: Numbers – Mat 1



· Help with learning numbers in French from 1 to 100, 1000s, 1,000,000s for Key Stage 2 &amp; 3 (age 7 to 13)



· The simple rules of French numbers and their variations are clearly explained on the front with exampl"/>

<meta property="og:image" content="image/fbog.png"/>



<link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet' type='text/css'>



<link href="index2963.html?route=product/product&amp;product_id=62" rel="canonical" />

<link rel="stylesheet" type="text/css" href="catalog/view/theme/elm/stylesheet/stylesheet.css" />

<link rel="stylesheet" type="text/css" href="catalog/view/theme/elm/stylesheet/jquery.bxslider.css" />

<link rel="stylesheet" type="text/css" href="catalog/view/javascript/jquery/colorbox/colorbox.css" media="screen" />

<script type="text/javascript" src="catalog/view/javascript/jquery/jquery-1.7.1.min.js"></script>

<script type="text/javascript" src="catalog/view/javascript/jquery/ui/jquery-ui-1.8.16.custom.min.js"></script>

<link rel="stylesheet" type="text/css" href="catalog/view/javascript/jquery/ui/themes/ui-lightness/jquery-ui-1.8.16.custom.css" />

<script type="text/javascript" src="catalog/view/javascript/jquery.bxslider.min.js"></script>

<script type="text/javascript" src="catalog/view/javascript/common.js"></script>

<script type="text/javascript" src="catalog/view/javascript/jquery/tabs.js"></script>

<script type="text/javascript" src="catalog/view/javascript/jquery/colorbox/jquery.colorbox-min.js"></script>

<!--[if IE 7]> 

<link rel="stylesheet" type="text/css" href="catalog/view/theme/default/stylesheet/ie7.css" />

<![endif]-->

<!--[if lt IE 7]>

<link rel="stylesheet" type="text/css" href="catalog/view/theme/default/stylesheet/ie6.css" />

<script type="text/javascript" src="catalog/view/javascript/DD_belatedPNG_0.0.8a-min.js"></script>

<script type="text/javascript">

DD_belatedPNG.fix('#logo img');

</script>

<![endif]-->


<!-- Raghav Responsive code -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
  <script type="text/javascript">
  
       $(function() 
       {
         
       $('body').on('click','.closePopup', function() 
         {
          $('.action input').css({backgroundColor: '#7c7c7c;',color: '#e6e6e6;'}).fadeOut(300, function() {
        $('.popupElement').remove()
        });
       });
         
     
       $('.seedemo').click(function(e) 
         {

        // Responsive code Raghav
          var width,height,real_width,real_height,height_to_width,width_to_height;
          real_width=748;
          real_height=499;
          real_width=parseInt(<?php echo $width;?>);
          real_height=parseInt(<?php echo $height;?>);
       // alert(real_width+":"+real_height);window.innerWidth;
          var height_cal = $(window).height();
          var width_cal = $(window).width(); 
          // alert(width_cal+":"+height_cal);
          if(height_cal<=width_cal)
          {
            height_cal= (height_cal-(height_cal*0.1))-120;
            width_to_height=real_width/real_height;
            width_cal=width_to_height*height_cal;
          }
          if(height_cal>width_cal)
          {
            width_cal= width_cal-(width_cal*0.3);
            height_to_width=real_height/real_width;
            height_cal=height_to_width*width_cal;
          }
       // alert(width_cal+":"+height_cal);
     if(id=="611"||id=="612"||id=="613"||id=="614"||id=="615")
                  height_cal-=15;

        // Responsive code Raghav

        e.preventDefault();
        var overlayy = $('<div/>').addClass('overlay').addClass('popupElement');
        $('body').append(overlayy);
        var popup = $('<div/>').addClass('popup').addClass('popupElement').css({left: '-999px'});
        var html = '<iframe src="https://www.3dwebcommerce.com/Separatefromopencart/index.php?id=<?php echo $id;?>&ro=1&responsive=1&width='+width_cal+'px&height='+height_cal+'px" name="frame2" id="frame2" frameborder="0" scrolling="no" overflow="hidden" overflow-y="hidden" seamless="seamless" marginwidth="0" marginheight="0" onload="" allowtransparency="false"></iframe><div class="action"><input type="button" value="&#215;" class="closePopup"/ style="margin-top:-7px;width:45px;opacity:1;height:20px;"></div>';//Default was PID:367 Opacity:0  btn height:20px Jithin Modified on 22 Jan 2016 as per INW-1 [JIRA]
        popup.html(html);
        $('body').append(popup); 
        var id=<?php echo $id;?>;
                   var left = ($(window).width()-width_cal)/2;
                var top =10;
                var width =  width_cal;
                if(id=="611"||id=="612"||id=="613"||id=="614"||id=="615")
                  var height = height_cal+50;
                else
                  var height = height_cal+120;
            popup.css({left: left + 'px', top: top + 'px', width: width + 'px', height: height + 'px'});
       });
       });
      
</script>
      
<style type="text/css">

        .overlay 
        {
          background: #999;
          position: absolute;
          left: 0;
          right: 0;
          bottom: 0;
          top: 0;
          opacity: 0.55;
          filter: alpha(opacity=95);
          z-index: 10000;
          height: 1600px;
          width: 100%;
        }
        
        .popup 
        {
          background: #fff;
          border-radius: 15px;
          padding: 9px;
          position: fixed;
          z-index: 10010;
          border: 10px solid #F6721F;
        }
        
        .popup div.action input 
        { /*Default  Jithin Modified on 22 Jan 2016 as per INW-1 [JIRA]*/
         /* background: #e6e6e6;
          color: #7c7c7c;
          border: #e6e6e6;*/
          background: transparent;
          color: #FB0000;
          border: 0px;
        }
        
        .closePopup
        {
          font-size: 30px;
          line-height: .5;
          position: absolute;
          /*top: 17px;*/
          /*right: 14px;*/ 
          top: 19px;/*Default 17px Jithin Modified on 22 Jan 2016 as per INW-1 [JIRA]*/
          right: 4px;/*Default 14px Jithin Modified on 22 Jan 2016 as per INW-1 [JIRA]*/
          color: #aaa;
          text-shadow: 0 -1px 1px rbga(0,0,0,.6);
          font-weight: bold;
          cursor: pointer;
        }

        iframe 
        {
          position: absolute;
          top: 0;
          bottom: 0;
          left: 0;
          right: 0;
          height: 100%;
          width: 100%;
          border-radius: 15px;
          padding-left: 5px; 
        }
  
</style>
<!-- Take till here -->

<!-- Raghav Responsive code -->



<script>

  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){

  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),

  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)

  })(window,document,'script','../www.google-analytics.com/analytics.js','ga');

 

  ga('create', 'UA-61075789-1', 'auto');

  ga('send', 'pageview');

 

</script></head>

<body>

    <div id="container">

        <div id="header">

                    <div id="logo">

                <a href="#">

                    <img src="image/data/logo.jpg" title="Educational Learning Mats" alt="Educational Learning Mats" />

                </a>

            </div>

        

            <div id="searchandbasket">

                <div id="search">

                    <input type="text" name="search" placeholder="Search for your perfect mat..." value="" />

                </div>

                <div id="cart">

    <div class="heading">

        <h4>

            Basket: <span id="cart-total">0 item(s)</span> - <a class="cartCheckout" href="index630e.html?route=checkout/checkout"></a>

        </h4>

    </div>

    <div class="content">

                <div class="empty">Your shopping cart is empty!</div>

            </div>

</div>



<script>

$(function () {});

    $('.add_to_cart').each(function(){

        var _pa = $(this);

        var _pid = _pa.attr('rel');

        _pa.click(function () {

            $.ajax({

                type: 'post',

                url: 'index.php?route=module/cart/callback',

                dataType: 'html',

                data: $('#product_'+_pid+' :input'),

                success: function (html) {

                    $('#module_cart .middle').html(html);

                },

                complete: function () {

                    var image = $('#image_'+_pid).offset();

                    var cart  = $('#module_cart').offset();



                    $('#image_'+_pid).before('<img src="' + $('#image_'+_pid).attr('src') + '" id="temp_'+_pid+'" style="position: absolute; top: ' + image.top + 'px; left: ' + image.left + 'px;" />');



                    params = {

                        top : cart.top + 'px',

                        left : cart.left + 'px',

                        opacity : 0.0,

                        width : $('#module_cart').width(),

                        heigth : $('#module_cart').height()

                    };

                    $('#temp_'+_pid).animate(params, 'slow', false, function () {

                        $('#temp_'+_pid).remove();

                    });

                }

            });

        });

    });

</script>                                <div class="links">

                    <a href="index630e.html?route=checkout/cart" style="padding:0 20px 0 15px;">Your Basket</a>

                    <a href="index5502.html?route=account/register">Create a free account today!</a>

                </div>

                <a class="login" href="indexe223.html?route=account/account"></a>

                

                <div class="emailsignup">



                    <form action="http://educationallearningmats.us8.list-manage.com/subscribe/post?u=8d7622d49672f81bfa68cdf99&amp;id=029107a818" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>

                        <input type="email" value="" name="EMAIL" class="email" id="mce-EMAIL" placeholder="Sign up to our mailing list" required>

                        <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->

                        <input class="hiddenVal" type="text" name="b_8d7622d49672f81bfa68cdf99_029107a818" tabindex="-1" value="">

                        <input type="submit" value="" name="subscribe" id="mc-embedded-subscribe">

                    </form>



                </div>

            </div>

         </div>

        <div id="topSubMenu">

            <ul>

                <li>

                    <a href="#">Home</a>

                </li>

                <li>

                    <a href="about.html">About us</a>

                </li>

                <li class="ourProducts"><span>Our Products</span>

                    <div id="ourProductsMenu">

                        <a href="all_products.html">All Our Products</a>

                        <a href="handwriting_mats.html">Handwriting</a>

                        <a href="french_mats.html">French</a>

                        <a href="spanish_mats.html">Spanish</a>

                        <a href="maths_mats.html">Maths</a>

                        <a href="pens.html">Pens</a>

                        <a href="ks1.html">Key Stage 1</a>

                        <a href="ks2.html">Key Stage 2</a>

                        <a href="ks3.html">Key Stage 3</a>

                    </div>

                </li>

                <li>

                    <a href="trade.html">Trade Enquiries & Schools</a>

                </li>

                <li class="phone">

                    <span>07785 990759</span>

                </li>

                <li class="email">

                    <a href="contact.html">info@elmats.com</a>

                </li>

            </ul>



        </div>

        <div id="paperClipSpacer"></div>

        <div id="notification"></div>

<div id="column-left">

    <div class="box">

  <div class="box-heading">Categories</div>

  <div class="box-content">

    <ul class="box-category">

  <div class="menuSpacer"></div>

            <li>

                <a href="all_products.html">All Our Products</a>

                      </li>

            <li>

                <a href="early_years.html">Early Years</a>

                      </li>

            <li>

                <a href="french_mats.html">French</a>

                        <ul>

                    <li>

                        <a href="french_mats/french_ks2.html"> - Key Stage 2 (2)</a>

                      </li>

                    <li>

                        <a href="french_mats/french_ks3.html"> - Key Stage 3 (2)</a>

                      </li>

                  </ul>

              </li>

            <li>

                <a href="spanish_and_french_mats.html">French &amp; Spanish</a>

                        <ul>

                    <li>

                        <a href="spanish_and_french_mats/french_spanish_ks2.html"> - Key Stage 2 (4)</a>

                      </li>

                    <li>

                        <a href="spanish_and_french_mats/french_spanish_ks3.html"> - Key Stage 3 (3)</a>

                      </li>

                  </ul>

              </li>

            <li>

                <a href="handwriting_mats.html">Handwriting</a>

                        <ul>

                    <li>

                        <a href="handwriting_mats/handwriting_ks1.html"> - Key Stage 1 (6)</a>

                      </li>

                  </ul>

              </li>

            <li>

                <a href="maths_mats.html">Maths</a>

                        <ul>

                    <li>

                        <a href="maths_mats/maths_ks1.html"> - Key Stage 1 (1)</a>

                      </li>

                    <li>

                        <a href="maths_mats/maths_ks2.html"> - Key Stage 2 (6)</a>

                      </li>

                  </ul>

              </li>

            <li>

                <a href="spanish_mats.html">Spanish</a>

                        <ul>

                    <li>

                        <a href="spanish_mats/spanish_ks2.html"> - Key Stage 2 (2)</a>

                      </li>

                    <li>

                        <a href="spanish_mats/spanish_ks3.html"> - Key Stage 3 (2)</a>

                      </li>

                  </ul>

              </li>

            <li>

                <a href="ks1.html">Key Stage 1</a>

                        <ul>

                    <li>

                        <a href="ks1/ks1_handwriting.html"> - Handwriting (6)</a>

                      </li>

                  </ul>

              </li>

            <li>

                <a href="ks2.html">Key Stage 2</a>

                        <ul>

                    <li>

                        <a href="ks2/ks2_french.html"> - French (2)</a>

                      </li>

                    <li>

                        <a href="ks2/ks2_maths.html"> - Maths (6)</a>

                      </li>

                    <li>

                        <a href="ks2/ks2_spanish.html"> - Spanish (2)</a>

                      </li>

                  </ul>

              </li>

            <li>

                <a href="ks3.html">Key Stage 3</a>

                        <ul>

                    <li>

                        <a href="ks3/ks3_french.html"> - French (2)</a>

                      </li>

                    <li>

                        <a href="ks3/ks3_french.html"> - Spanish (2)</a>

                      </li>

                  </ul>

              </li>

            <li>

                <a href="pens.html">Pens</a>

                      </li>

          </ul>



  <div class="menuSpacer"></div>

      <ul class="usps">

    <li>Bright, colourful, inviting, accessible.</li>

    <li>Hands on activities, helping children to learn those tricky basics.</li>

    <li>A useful link between home and school.  Good for revision.</li>

    <li>Re-usable, write on wipe clean learning mats.</li>

      </ul>

  </div>

</div>

  </div>

 

<div id="content" class="ksSubject_French">

    <div class="breadcrumb bcnomargin">

        <a href="index9328.html?route=common/home">Home</a>

         &raquo; <a href="index2963.html?route=product/product&amp;product_id=62"> <?php echo $product_name; ?></a>

      </div>

  <h1 style="

    width: 60%;

    float: left;
    

"> <?php echo $product_name; ?> </h1> 





<div style="height: 150px;width:40%;float: right;">



<img src="<?php echo $image_gif;?>" style="margin-right: 177px;height:75px;width:100px;float: right;">

</div>





 <div id="pos">

  <button type="submit" class=" seedemo single_add_to_cart_button button alt  " style=" background: url(img/yellowBtn.jpg) top left no-repeat !important;

    display: block;

    width: 150px;

    height: 38px;

    text-align: center;

    color: #FFFFFF !important;

    padding-top: 0px;

    border: 0px;

    font-size: 15px;

    font-family: 'elm';



    margin-bottom: -3px;

    cursor: pointer;">Click to interact</button>



  </div>



  

  <style>

  #pos

  {

    position:absolute;

    top:120px;

    left:425px;

    z-index:500;

  }







  </style>





  <div class="product-info">

        <div class="left">

            <div class="image">
            <a href="<?php echo $image_1;?>" title="French Essentials" class="colorbox">
            <img src="<?php echo $image_2;?>" title="French Essentials" alt="French Essentials" id="image" /></a></div>

                  <div class="image-additional">

                <a href="<?php echo $image_3;?>" title="French Essentials" class="colorbox">
                <img src="<?php echo $image_4;?>" title="French Essentials" alt="French Essentials" /></a>

                
      </div>

          </div>

        <div class="right">

      <div class="description">

                <span>Product Code:</span> Numbers<br />

                <span>Availability:</span> 62</div>

            <div class="price">



          <!--

        <div class="diffPrices">

                        

                                            <span>A4: £3.99</span>

                                            <span>A3: £4.99</span>

                                                    </div>

        //-->



                                              </div>

                  <div class="options">

        <br />

                        <div id="option-245" class="option">

                              <select name="option[245]">

            <option value="">Please select mat size</option>                        <option value="48">A4                        (£3.99)

                        </option>

                        <option value="49">A3                        (£4.99)

                        </option>

                      </select>

        </div>

        <br />

                                                                                              </div>

            <div class="cart">

          <div class="qty">

              Quantity:

              <input type="text" name="quantity" size="2" value="1" />

          </div>

        <div>

          <input type="hidden" name="product_id" size="2" value="62" /><br>

          <span class="addToCart" id="button-cart" class="button" />Add to basket</span>

          <div class="checkout">

            <a href="index630e.html?route=checkout/cart">Your basket</a>

          </div>



            <div class="share"><!-- AddThis Button BEGIN -->

                <a class="addthis_button_print"><img src="catalog/view/theme/elm/img/sharePrint.png"> Print</a>

                <a class="addthis_button_email"><img src="catalog/view/theme/elm/img/shareEmail.png"> Email</a><br>

                <a class="addthis_button_facebook"><img src="catalog/view/theme/elm/img/shareFacebook.png"> Share</a>

                <a onclick="addToWishList('62');"><img src="catalog/view/theme/elm/img/shareWish.png"> Add to Wish List</a>

                <script type="text/javascript" src="../s7.addthis.com/js/250/addthis_widget.js"></script>

            <!-- AddThis Button END -->

            </div>





        </div>

              </div>

            <div class="review">

        <div><img src="catalog/view/theme/default/image/stars-0.png" alt="0 reviews" />&nbsp;&nbsp;<a onclick="$('a[href=\'#tab-review\']').trigger('click');">0 reviews</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a onclick="$('a[href=\'#tab-review\']').trigger('click');">Write a review</a></div>

        <div class="share"><!-- AddThis Button BEGIN -->

          <div class="addthis_default_style"><a class="addthis_button_compact">Share</a> <a class="addthis_button_email"></a><a class="addthis_button_print"></a> <a class="addthis_button_facebook"></a> <a class="addthis_button_twitter"></a></div>

          <script type="text/javascript" src="../s7.addthis.com/js/250/addthis_widget.js"></script> 

          <!-- AddThis Button END --> 

        </div>

      </div>

          </div>

    <div class="productDescription">

        <h2>Product Details</h2>

        <p>French Essentials: The Calendar – Mat 2</p>



<ul>

  <li>Help with learning French – days in a month, days of the week, months of the year, years, and other useful words and phrases for Key Stage 2 &amp; 3 (age 7 to 13).</li>

  <li>The simple rules and phrases for describing dates and days are clearly explained on the front with examples; on the back children can test their knowledge, a little bit at a time.</li>

  <li>Consistent with national curriculum – as taught in schools</li>

</ul>

    </div>

  </div>









    <div class="related product-grid">

      <h2>Related products</h2>

            <div>

                <div class="image"><a href="index7668.html?route=product/product&amp;product_id=60"><img src="image/cache/data/French/French-Verbs-final-1-207x167.jpg" alt="Irregular Verbs" /></a></div>

                <div class="name"><a href="index7668.html?route=product/product&amp;product_id=60">Irregular Verbs</a></div>

                <div class="price">

          <strong>Starting from:</strong>

                    £3.99                  </div>

                        <a href="index7668.html?route=product/product&amp;product_id=60" class="button">See more</a></div>

            <div>

                <div class="image"><a href="index086b.html?route=product/product&amp;product_id=61"><img src="image/cache/data/French/French-Calendar-1-207x167.jpg" alt="French Calendar" /></a></div>

                <div class="name"><a href="index086b.html?route=product/product&amp;product_id=61">French Calendar</a></div>

                <div class="price">

          <strong>Starting from:</strong>

                    £3.99                  </div>

                        <a href="index086b.html?route=product/product&amp;product_id=61" class="button">See more</a></div>

          </div>



      </div>

<script type="text/javascript"><!--

$(document).ready(function() {

  $('.colorbox').colorbox({

    overlayClose: true,

    opacity: 0.5,

    rel: "colorbox"

  });

});

//--></script> 

<script type="text/javascript"><!--

$('#button-cart').bind('click', function() {

  $.ajax({

    url: 'index.php?route=checkout/cart/add',

    type: 'post',

    data: $('.product-info input[type=\'text\'], .product-info input[type=\'hidden\'], .product-info input[type=\'radio\']:checked, .product-info input[type=\'checkbox\']:checked, .product-info select, .product-info textarea'),

    dataType: 'json',

    success: function(json) {

      $('.success, .warning, .attention, information, .error').remove();

      

      if (json['error']) {

        if (json['error']['option']) {

          for (i in json['error']['option']) {

            $('#option-' + i).after('<span class="error">' + json['error']['option'][i] + '</span>');

          }

        }

      } 

      

      if (json['success']) {

        $('#notification').html('<div class="success" style="display: none;">' + json['success'] + '<img src="catalog/view/theme/default/image/close.png" alt="" class="close" /></div>');

          

        $('.success').fadeIn('slow');

          

        $('#cart-total').html(json['total']);

        

        $('html, body').animate({ scrollTop: 0 }, 'slow'); 

      } 

    }

  });

});

//--></script>

<script type="text/javascript" src="catalog/view/javascript/jquery/ajaxupload.js"></script>

<script type="text/javascript"><!--

$('#review .pagination a').live('click', function() {

  $('#review').fadeOut('slow');

    

  $('#review').load(this.href);

  

  $('#review').fadeIn('slow');

  

  return false;

});     



$('#review').load('indexc12f.html?route=product/product/review&amp;product_id=62');



$('#button-review').bind('click', function() {

  $.ajax({

    url: 'index.php?route=product/product/write&product_id=62',

    type: 'post',

    dataType: 'json',

    data: 'name=' + encodeURIComponent($('input[name=\'name\']').val()) + '&text=' + encodeURIComponent($('textarea[name=\'text\']').val()) + '&rating=' + encodeURIComponent($('input[name=\'rating\']:checked').val() ? $('input[name=\'rating\']:checked').val() : '') + '&captcha=' + encodeURIComponent($('input[name=\'captcha\']').val()),

    beforeSend: function() {

      $('.success, .warning').remove();

      $('#button-review').attr('disabled', true);

      $('#review-title').after('<div class="attention"><img src="catalog/view/theme/default/image/loading.gif" alt="" /> Please Wait!</div>');

    },

    complete: function() {

      $('#button-review').attr('disabled', false);

      $('.attention').remove();

    },

    success: function(data) {

      if (data['error']) {

        $('#review-title').after('<div class="warning">' + data['error'] + '</div>');

      }

      

      if (data['success']) {

        $('#review-title').after('<div class="success">' + data['success'] + '</div>');

                

        $('input[name=\'name\']').val('');

        $('textarea[name=\'text\']').val('');

        $('input[name=\'rating\']:checked').attr('checked', '');

        $('input[name=\'captcha\']').val('');

      }

    }

  });

});

//--></script> 

<script type="text/javascript"><!--

$('#tabs a').tabs();

//--></script> 

<script type="text/javascript" src="catalog/view/javascript/jquery/ui/jquery-ui-timepicker-addon.js"></script> 

<script type="text/javascript"><!--

$(document).ready(function() {

  if ($.browser.msie && $.browser.version == 6) {

    $('.date, .datetime, .time').bgIframe();

  }



  $('.date').datepicker({dateFormat: 'yy-mm-dd'});

  $('.datetime').datetimepicker({

    dateFormat: 'yy-mm-dd',

    timeFormat: 'h:m'

  });

  $('.time').timepicker({timeFormat: 'h:m'});

});

//--></script> 

        <div id="footer">

            <ul class="bottomLinks">

                <li><a href="about.html">About Us</a></li>

                <li><a href="trade.html">Trade Enquires</a></li>

                <li><a href="qanda.html">Questions & Answers</a></li>

                <li><a href="privacy.html">Privacy Policy</a></li>

                <li><a href="testimonials.html">Testimonials</a></li>

                <li><a href="contact.html">Contact Us</a></li>

                <li><a href="indexe223.html?route=account/account">My Account</a></li>

                <li><a href="indexe223.html?route=account/wishlist">Wish List</a></li>

                <li><a href="delivery_returns.html">Delivery & Returns</a></li>

                <li><a href="termsandconditions.html">Terms & Conditions</a></li>

            </ul>

            <div class="paymentOptions"></div>

            <p class="right green">Designed by teachers & made in the UK. Follow us

                <a href="http://www.facebook.com/educationallearningmats" target="_blank"><img src="catalog/view/theme/elm/img/footerFacebook.jpg" width="18" height="18"/></a>

                <a href="https://twitter.com/ELMatsLtd" target="_blank"><img src="catalog/view/theme/elm/img/footerTwitter.jpg" width="18" height="18"/></a>

                <!--<a href="#"><img src="catalog/view/theme/elm/img/footerLinkedIn.jpg" width="18" height="18"/></a>//-->

            </p>

            <p class="right copyRight">&copy; Educational Learning Mats & Lucy Moore 2013. Web design by <a href="http://www.mikegarlick.com/" target="_blank">MikeGarlick</a> & <a href="http://www.gelstudios.co.uk/" target="_blank">GEL Studios</a></p>

        </div>

    </body>



<!-- Mirrored from www.educationallearningmats.co.uk/index.php?route=product/product&product_id=62 by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 28 Mar 2016 11:57:23 GMT -->

</html>