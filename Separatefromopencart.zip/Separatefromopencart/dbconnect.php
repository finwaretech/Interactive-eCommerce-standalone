<?php
mysql_connect("localhost","root","password")
or die("<h3>could not connect to MySQL</h3>\n");
mysql_select_db("webcommerce")
or die("<h3>could not select database</h3>\n");
?>

